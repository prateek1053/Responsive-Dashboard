  //toggle functionality
  function navopen() {
      var nav = document.getElementById("demo");
      var navigation_panel = document.getElementById("left");

      nav.classList.toggle("active");
      navigation_panel.classList.remove("active");

  }
  function navigation_panel() {
      var navigation_panel = document.getElementById("left");
       var nav = document.getElementById("demo");
       navigation_panel.classList.toggle("active");
         nav.classList.remove("active");

  }
    //toggle functionality end


//circle progress bar code
var progress_circle = document.querySelector(".progressbar_circle");
var value_container = document.querySelector(".value_container");
var initial_value = 0;
var target_value = 50;
var speed = 50;

let progress_fun = setInterval(function() {
  initial_value++;

  value_container.textContent= `${initial_value}%`;
  progress_circle.style.background =`conic-gradient(
  #1540a8 ${initial_value * 3.6}deg,
   #cadcff ${initial_value * 3.6}deg
  )`;
  if(initial_value == target_value)
  {
    clearInterval(progress_fun);
  }
},speed);
//circle progress bar code end


//Progress bar 
function loading() {
  document.querySelectorAll(".inner_div").forEach(function(current) {
    let startWidth = 0;
    const targetWidth = current.dataset.size;
 
    const interval = setInterval(frame, 20);

    function frame() {

       startWidth++;
          current.style.width = `${startWidth}%`;
          current.firstElementChild.innerText = `${startWidth}%`;        
      if (startWidth >= targetWidth) {
        clearInterval(interval);
      } 
     }
  });
}
loading();
//Progress bar end


// counter the number
    window.onload = ()=>{
        $("#num1").countMe(40,65);
        $("#num2").countMe(40, 65);
        $("#num3").countMe(40, 65);
        $("#num4").countMe(40,65);
        $("#num5").countMe(40,65);
        $("#num6").countMe(40, 65);
        $("#num7").countMe(40, 65);
        $("#num8").countMe(40, 65);
        $("#num9").countMe(40, 65);
        $("#num10").countMe(40, 65);
     }
// counter the number end


//chart js

var ctx = document.getElementById("myChart").getContext("2d");
var background_1 = ctx.createLinearGradient(0, 0, 0, 450);
background_1.addColorStop(0, '#0030a1');
background_1.addColorStop(1, '#fff');

var background_2 = ctx.createLinearGradient(0, 0, 0, 450);
background_2.addColorStop(0, 'red');
background_2.addColorStop(1, '#fff');

var background_3 = ctx.createLinearGradient(0, 0, 0, 450);
background_3.addColorStop(0, '#3fc7a8');
background_3.addColorStop(1, '#fff');

      var mychart =new Chart(ctx,{
        type :"bar",
        data:{
          labels :["jan","Feb","Mar"],
          datasets:[
          {
            data:[100,65,90],
            label :"Ongoing",
            backgroundColor :background_1

          },
          {
            data:[55,100,50],
            label :"Pending",
            backgroundColor :background_2
          },
          {
            data:[25,30,100],
            label :"Completed",
            backgroundColor :background_3
          },
          ],
        },
       options:{
       /* reponsive:"false",*/
       legend:{
        display:true,
        position:"bottom",
        labels:{
          boxWidth :15,
          fontSize:15,
        }
       }
       }
      })
//chart js end